package Quiz;
import java.util.*;


/*
*********************************
 Methods
   getquiz method will generate 2random numbers and will choose a random sign i.e + or - and will set the it's answer return this question to the maingame class belonging from home.java file and answer too whenver the maingame needs the answer to check whether the user's selected option has correct answer or not
   this answer is returned to the main by the getnas() method.

   getcompturn method  will tell the computer whether to give right answers or wrong answer if true is returned from this code then it will right answer or else it will give wrong answer.

   getranddice method will return the the which number will appear on dice by randomly chooosing from 0 to 6 this range

*********************************
*/
public class QuizGen
{
    int ans = 0;
    int lowlim=1;
    int highlim=50;

    public String getquiz()
    { 
        Random rand = new Random();
        char sign[]={'+','-'};
        int no1 = rand.nextInt(highlim);
        int no2 = rand.nextInt(highlim);
        if(no1<lowlim){no1 = no1+lowlim;}
        if(no2<lowlim){no2 = no2+lowlim;}

        char signstr=sign[rand.nextInt(2)];

        if(signstr=='+')
        {this.ans = no1+no2;}
        if(signstr=='-' && no1<no2)
        {this.ans = no2-no1;}
        else if(signstr=='-' && no1>no2)
        {this.ans = no1-no2;}

        if(no1<no2 && signstr =='-')
        {
            String quiz = Integer.toString(no2)+signstr+Integer.toString(no1);
            return quiz;
        }
        else
        {
        String quiz = Integer.toString(no1)+signstr+Integer.toString(no2);
        return quiz;
        }
    }

    public int getans()
    {
        return this.ans;
    }

    public int getrand()
    {
        Random rand = new Random();
        return rand.nextInt(highlim)+lowlim;
    }

    public boolean getcompturn()
    {
        Random rand = new Random();
        return rand.nextBoolean();
    }

    public int getranddice()
    {
        Random rand = new Random();
        return rand.nextInt(6);
    }
}