package Screens;
import javax.swing.*;
import java.awt.*;
import java.util.Random;
import javax.sound.sampled.*;

import java.awt.event.*;
import Audio.Sound;
import javax.swing.border.Border;
import Profile.Player;
import Quiz.QuizGen;  
import Quiz.cord; 
import Quiz.Database; 

//Compile this using javac -d . Home.java
//and after successful compilation 
//then run ur main Start file 


/***************************************
    Home class contains all the components of home screen the Initialization of Sound Object Happens here 
    and is passed to the other classes in the code.

    When play button gets pressed inside the Home Class's Object the current frame gets dispose
    and the object of Select class i.e the next screen's class is initialized and 
    the constructor of that class gets executed automatically the ui(user interface) or next screen gets created and is shown on screen
 ***************************************/
public class Home implements ActionListener
{
    JFrame frame;
    JLabel bgl,titlel;
    JButton play;
    ImageIcon bg,title,playbut;
    Sound sobj = new Sound("Audio/bgclip.wav");
    
    public Home()
    {
        frame = new JFrame();
        play = new JButton();
        bgl = new JLabel();
        titlel = new JLabel();
        
        frame.setSize(815,638);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        sobj.play();

        bg = new ImageIcon("Pics/bg1.jpg");
        title = new ImageIcon("Pics/title.png");
        playbut = new ImageIcon("Pics/play.png");

        bgl.setBounds(0,0,800,600);
        bgl.setIcon(bg);
        
        titlel.setBounds(0,0,800,600);
        titlel.setIcon(title);

        play.setBounds(340,460,180,50);
        //play.setForeground(Color.black);
        play.setIcon(playbut);
        //play.setFont(new Font("Serif",Font.BOLD,14));
        play.setFocusable(false);

        frame.add(titlel);
        frame.add(play);
        frame.add(bgl);

        play.addActionListener(this);

        frame.setLayout(null);
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent aobj)
    {
        if(aobj.getSource() == play)
        {
            frame.dispose();
            sobj.setsound(true);
            sobj.setmusic(true);
            sobj.playone("Audio/click.wav");
            try{
            Select sobj1 = new Select(sobj);
            }
            catch(Exception eobj){}
        }
    }
}

/***************************************
    Select Screen Has all the game modes and setting 
    here, flag and flag1 variable are initialised to declare a condition of on/off for our music and sound on off button if on value == 1 and if off value == 0
    same for  flag2 and highflag these two are used to close the opened screen of highscore and the settings and rule menu.
    if flag2==0 and close button is pressed close the setting's menu
    if flag2==1 and close button is pressed close the rule menu and make the value of flag2's value again 0 and show setting's menu.

    To make the sound and music on and off we used the inbuilt library of java (javax.sound.sampled.*) which allows us to import the audio file of WAV format and to play them or stop them.
    
    all the sound related explaination is in the Sound.java file which is an user defined library/package.
    to use the methods that are written in our sound.java library we are passing the sobj which is our sound object from one class to another class 
    and we are cloning that object so that the initialised values of sobj remains the same through out the game 
    for.e.g if sound is turned off then the soundflag variable of sobj remains 0 through out the program unless and until someone turns it on from setting's menu
    which results in changing the value of soundflag to 1.

 ***************************************/
class Select implements ActionListener
{
    JFrame frame;
    JButton sett,single,twop,closebut,onbut,onbut1,rulebut,highbut,exitbut;
    JLabel bglab,titlelab,setmen,rulelab,highlab,highmenulab;
    ImageIcon bg,setp,singlep,twopp,titl,men,close,onimg,offimg,rule,ruleimg,highimg,exitimg,highmenuimg;
    int flag = 1,flag1 = 1, flag2=0,highflag = 0;
    Sound sobj;
    Border border = BorderFactory.createLineBorder(Color.black,3);

    public Select(Sound sobj1)throws Exception
    {
        sobj = (Sound)sobj1.clone();

        frame = new JFrame();
        sett = new JButton();
        single = new JButton();
        twop = new JButton();
        highbut = new JButton();
        exitbut = new JButton();
        closebut = new JButton();
        onbut = new JButton();
        onbut1 = new JButton();
        rulebut = new JButton();
        bglab = new JLabel();
        titlelab = new JLabel();
        setmen = new JLabel();
        rulelab = new JLabel();
        highlab = new JLabel();
        highmenulab = new JLabel();

        bg = new ImageIcon("Pics/bg2.jpg");
        setp = new ImageIcon("Pics/set.png");
        singlep = new ImageIcon("Pics/onepp.png");
        twopp = new ImageIcon("Pics/twopp.png");
        titl = new ImageIcon("Pics/titbg2.png");
        men = new ImageIcon("Pics/setmenu.png");
        close = new ImageIcon("Pics/closebut.png");
        onimg = new ImageIcon("Pics/yesbut.png");
        offimg = new ImageIcon("Pics/nobut.png");
        rule = new ImageIcon("Pics/rulebut.png");
        ruleimg = new ImageIcon("Pics/rule.png");
        highimg = new ImageIcon("Pics/high.png");
        exitimg = new ImageIcon("Pics/exit.png");
        highmenuimg = new ImageIcon("Pics/highmenu.png");

        frame.setSize(815,638);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        bglab.setBounds(0,0,800,600);
        bglab.setIcon(bg);
        
        titlelab.setBounds(160,20,625,215);
        titlelab.setIcon(titl);

        single.setBounds(130,200,200,120);
        single.setIcon(singlep);
        single.setFocusable(false);
        
        twop.setBounds(500,200,200,120);
        twop.setIcon(twopp);
        twop.setFocusable(false);
        
        highbut.setBounds(130,380,200,120);
        highbut.setIcon(highimg);
        highbut.setFocusable(false);
        
        exitbut.setBounds(500,380,200,120);
        exitbut.setIcon(exitimg);
        exitbut.setFocusable(false);
        
        sett.setBounds(710,520,74,65);
        sett.setIcon(setp);
        sett.setFocusable(false);
        
        closebut.setBounds(530,117,47,41);
        closebut.setIcon(close);
        closebut.setFocusable(false);
        closebut.setVisible(false);
        
        onbut.setBounds(455,200,109,48);
        if(sobj.musicflag == true)
        {onbut.setIcon(onimg);}
        else
        {onbut.setIcon(offimg);flag=0;}
        onbut.setFocusable(false);
        onbut.setVisible(false);
        
        onbut1.setBounds(455,280,109,48);
         if(sobj.soundflag == true)
        {onbut1.setIcon(onimg);}
        else
        {onbut1.setIcon(offimg);flag1=0;}
        onbut1.setFocusable(false);
        onbut1.setVisible(false);
        
        rulebut.setBounds(368,369,113,52);
        rulebut.setIcon(rule);
        rulebut.setFocusable(false);
        rulebut.setVisible(false);
        
        setmen.setBounds(0,0,800,600);
        setmen.setIcon(men);
        setmen.setVisible(false);
        
        rulelab.setBounds(0,0,800,600);
        rulelab.setIcon(ruleimg);
        rulelab.setVisible(false);

        highmenulab.setBounds(0,0,800,600);
        highmenulab.setIcon(highmenuimg);
        highmenulab.setVisible(false);

        highlab.setBounds(190,190,460,340);
        highlab.setForeground(Color.black);
        highlab.setVisible(false);
        
        single.addActionListener(this);
        twop.addActionListener(this);
        highbut.addActionListener(this);
        exitbut.addActionListener(this);
        sett.addActionListener(this);
        closebut.addActionListener(this);
        onbut.addActionListener(this);
        onbut1.addActionListener(this);
        rulebut.addActionListener(this);
        
        
        frame.add(highlab);
        frame.add(closebut);
        frame.add(highmenulab);
        frame.add(onbut);
        frame.add(onbut1);
        frame.add(rulebut);
        frame.add(rulelab);
        frame.add(setmen);
        frame.add(single);
        frame.add(twop);
        frame.add(highbut);
        frame.add(exitbut);
        frame.add(sett);
        frame.add(titlelab);
        frame.add(bglab);

        frame.setLayout(null);
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent aobj)
    {

        if(aobj.getSource()==single)
        {
            sobj.playone("Audio/click.wav");
            frame.dispose();
            try
            {
            Mode1 mobj = new Mode1(sobj);
            }
            catch(Exception eobj){}
        }

        else if(aobj.getSource()==twop)
        {
            sobj.playone("Audio/click.wav");
            frame.dispose();
            try
            {
            Mode2 mobj = new Mode2(sobj);
            }
            catch(Exception eobj){}
        }

        else if(aobj.getSource()==sett)
        {
            sobj.playone("Audio/click.wav");
            setmen.setVisible(true);
            closebut.setVisible(true);
            onbut.setVisible(true);
            onbut1.setVisible(true);
            rulebut.setVisible(true);
            single.setVisible(false);
            twop.setVisible(false);
            sett.setVisible(false);
            highbut.setVisible(false);
            exitbut.setVisible(false);
        }

        else if(aobj.getSource()==closebut && flag2!=1)
        {
            sobj.playone("Audio/click.wav");
            setmen.setVisible(false);
            closebut.setVisible(false);
            onbut.setVisible(false);
            onbut1.setVisible(false);
            rulebut.setVisible(false);
            single.setVisible(true);
            twop.setVisible(true);
            sett.setVisible(true);
            highbut.setVisible(true);
            exitbut.setVisible(true);
        }

        else if(aobj.getSource()==closebut && flag2==1)
        {
            flag2--;
            sobj.playone("Audio/click.wav");
            setmen.setVisible(true);
            onbut.setVisible(true);
            onbut1.setVisible(true);
            rulebut.setVisible(true);
            rulelab.setVisible(false);
            closebut.setBounds(530,117,47,41);
        }

        else if(aobj.getSource() == onbut && flag == 1)
        {
            sobj.playone("Audio/click.wav");
            onbut.setIcon(offimg);
            sobj.setmusic(false);
            sobj.musicoff();
            flag = 0;
        }
        
        else if(aobj.getSource() == onbut && flag != 1)
        {
            sobj.playone("Audio/click.wav");
            onbut.setIcon(onimg);
            sobj.setmusic(true);
            sobj.musicon();
            flag = 1;
        }
        
        else if(aobj.getSource()==onbut1 && flag1 == 1)
        {
            sobj.playone("Audio/click.wav");
            onbut1.setIcon(offimg);
            sobj.setsound(false);
            flag1 = 0;
        }
        
        else if(aobj.getSource()==onbut1 && flag1 != 1)
        {
            
            onbut1.setIcon(onimg);
            sobj.setsound(true);
            flag1 = 1;
        }
        
        else if(aobj.getSource()==rulebut)
        {
            flag2++;
            sobj.playone("Audio/click.wav");
            setmen.setVisible(false);
            onbut.setVisible(false);
            onbut1.setVisible(false);
            rulebut.setVisible(false);
            rulelab.setVisible(true);
            closebut.setBounds(718,112,47,41);
        }

        if(aobj.getSource()==highbut && highflag == 0)
        {
            sobj.playone("Audio/click.wav");
            closebut.setVisible(true);
            single.setVisible(false);
            twop.setVisible(false);
            highbut.setVisible(false);
            exitbut.setVisible(false);
            sett.setVisible(false);
            Database dobj = new Database();
            String str = dobj.showhighscore();
            highmenulab.setVisible(true);
            highlab.setFont(new Font("Serif",Font.BOLD,24));
            highlab.setHorizontalAlignment(JLabel.CENTER);
            highlab.setText(str);
            highlab.setVisible(true);
            highflag++;
        }
        
        if(aobj.getSource()==closebut && highflag ==1)
        {
            sobj.playone("Audio/click.wav");
            closebut.setVisible(false);
            single.setVisible(true);
            twop.setVisible(true);
            highbut.setVisible(true);
            exitbut.setVisible(true);
            sett.setVisible(true);
            Database dobj = new Database();
            String str = dobj.showhighscore();
            highmenulab.setVisible(false);
            highlab.setFont(new Font("Serif",Font.BOLD,24));
            // highlab.setBorder(border);
            highlab.setHorizontalAlignment(JLabel.CENTER);
            highlab.setText(str);
            highlab.setVisible(false);
            highflag--;
        }

        if(aobj.getSource()==exitbut)
        {
            sobj.playone("Audio/click.wav");
            frame.dispose();
        }

    }
}


/***************************************
    In this mode 1 class we are setting the profile and username of our player.
    Mode 1 class is single player mode of our game i.e user vs computer.
    In this class we are setting the computer's username to Computer and profile to the default profile from our file.
    In this class we are checking whether the username is less than 8 and greater than 0 and is not equal to (Computer)this name as it is already set default for the computer.
    Once the profile is set then we can click confirm button Continue to actual game.
 ***************************************/
class Mode1 implements ActionListener
{
    JFrame frame;
    ImageIcon bg,profimg1,profimg2,profimg3,profimg4,profimg5,profimg6,profimg7,profimg8,selectimg,backimg,compimg;
    JLabel bglab,profsel,selectedlab,head;
    JTextField uname;
    JButton probut1,probut2,probut3,probut4,probut5,probut6,probut7,probut8,backbut,confirmbut;
    
    Sound sobj;
    Player playerobj = new Player();
    Player computerobj = new Player();
    
    //Image img;
    
    Border border = BorderFactory.createLineBorder(Color.white,3);
    Border blackborder = BorderFactory.createLineBorder(Color.black,3);

    public Mode1(Sound sobj1)throws Exception
    {

        // Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        // int width = (int)size.getWidth(); 
        // int height = (int)size.getHeight();
        this.sobj=(Sound)sobj1.clone();
        frame = new JFrame();
        bg = new ImageIcon("Pics/bg2.jpg");
        bglab = new JLabel();
        profsel = new JLabel();
        selectedlab = new JLabel();
        head = new JLabel();
        uname = new JTextField("Player 1");

        probut1 =  new JButton();
        probut2 =  new JButton();
        probut3 =  new JButton();
        probut4 =  new JButton();
        probut5 =  new JButton();
        probut6 =  new JButton();
        probut7 =  new JButton();
        probut8 =  new JButton();
        backbut =  new JButton();
        confirmbut =  new JButton();

        profimg1 = new ImageIcon("Pics/prof/prof1.png");
        profimg2 = new ImageIcon("Pics/prof/prof2.png");
        profimg3 = new ImageIcon("Pics/prof/prof3.png");
        profimg4 = new ImageIcon("Pics/prof/prof4.png");
        profimg5 = new ImageIcon("Pics/prof/prof5.png");
        profimg6 = new ImageIcon("Pics/prof/prof6.png");
        profimg7 = new ImageIcon("Pics/prof/prof7.png");
        profimg8 = new ImageIcon("Pics/prof/prof8.png");
        compimg = new ImageIcon("Pics/prof/robo.png");
        selectimg = new ImageIcon("Pics/prof/select.png");
        backimg = new ImageIcon("Pics/backbut.png");
        
        frame.setSize(815,638);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        bglab.setBounds(0,0,800,600);
        bglab.setIcon(bg);
        bglab.setVerticalAlignment(JLabel.TOP);
        bglab.setOpaque(true);
        bglab.setBackground(Color.black);

        uname.setBounds(260,435,286,60);
        uname.setBackground(new Color(90,61,37));
        uname.setForeground(Color.white);
        uname.setOpaque(true);
        uname.setFont(new Font("Serif",Font.BOLD,34));
        uname.setBorder(blackborder);
        uname.setText("Player 1");
        uname.setHorizontalAlignment(JTextField.CENTER);
        uname.setVisible(false);
       
        head.setBounds(115,26,589,76);
        head.setBackground(new Color(90,61,37));
        head.setForeground(Color.white);
        head.setOpaque(true);
        head.setFont(new Font("Serif",Font.BOLD,34));
        head.setBorder(border);
        head.setText("Select Profile and Enter Username");
        head.setHorizontalAlignment(JLabel.CENTER);

        profsel.setBounds(50,133,696,275);
        profsel.setBackground(new Color(90,61,37));
        profsel.setOpaque(true);
        profsel.setBorder(border);

        selectedlab.setBounds(80,146,136,117);
        selectedlab.setIcon(selectimg);
        selectedlab.setVisible(false);

        probut1.setBounds(80,146,136,117);
        probut1.setIcon(profimg1);
        
        probut2.setBounds(80+34+136,146,136,117);
        probut2.setIcon(profimg2);
        
        probut3.setBounds(80+(136*2)+(34*2),146,136,117);
        probut3.setIcon(profimg3);
        
        probut4.setBounds(80+(136*3)+(34*3),146,136,117);
        probut4.setIcon(profimg4);
        
        probut5.setBounds(80,277,136,117);
        probut5.setIcon(profimg5);
        
        probut6.setBounds(80+34+136,277,136,117);
        probut6.setIcon(profimg6);
        
        probut7.setBounds(80+(136*2)+(34*2),277,136,117);
        probut7.setIcon(profimg7);
        
        probut8.setBounds(80+(136*3)+(34*3),277,136,117);
        probut8.setIcon(profimg8);
        
        backbut.setBounds(5,33,51,51);
        backbut.setIcon(backimg);
        
        confirmbut.setBounds(310,534,190,40);
        confirmbut.setBackground(new Color(211,172,123));
        confirmbut.setForeground(Color.black);
        confirmbut.setText("CONFIRM");
        confirmbut.setFont(new Font("Serif",Font.BOLD,26));
        confirmbut.setVisible(false);
        confirmbut.setFocusable(false);

        probut1.addActionListener(this);
        probut2.addActionListener(this);
        probut3.addActionListener(this);
        probut4.addActionListener(this);
        probut5.addActionListener(this);
        probut6.addActionListener(this);
        probut7.addActionListener(this);
        probut8.addActionListener(this);
        backbut.addActionListener(this);
        confirmbut.addActionListener(this);

        // img = bg.getImage();
        // img = img.getScaledInstance(width,height,java.awt.Image.SCALE_SMOOTH);
        // bg = new ImageIcon(img);


        // System.out.println(width);
        // System.out.println(height);

        frame.add(head);
        frame.add(uname);
        frame.add(selectedlab);
        frame.add(probut1);
        frame.add(probut2);
        frame.add(probut3);
        frame.add(probut4);
        frame.add(probut5);
        frame.add(probut6);
        frame.add(probut7);
        frame.add(probut8);
        frame.add(backbut);
        frame.add(confirmbut);
        frame.add(profsel);
        frame.add(bglab);
        
        frame.setLayout(null);
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent aobj)
    {
        if(aobj.getSource()==probut1)
        {
            probut1.setEnabled(false);
            playerobj.setprofile(profimg1);
            computerobj.setprofile(compimg);
            confirmbut.setVisible(true);
            sobj.playone("Audio/click.wav");
            uname.setVisible(true);
        }else{probut1.setEnabled(true);}

        if(aobj.getSource()==probut2)
        {
            probut2.setEnabled(false);
            playerobj.setprofile(profimg2);
            computerobj.setprofile(compimg);
            confirmbut.setVisible(true);
            sobj.playone("Audio/click.wav");
            uname.setVisible(true);
        }else{probut2.setEnabled(true);}
        
        if(aobj.getSource()==probut3)
        {
            probut3.setEnabled(false);
            playerobj.setprofile(profimg3);
            computerobj.setprofile(compimg);
            confirmbut.setVisible(true);
            sobj.playone("Audio/click.wav");
            uname.setVisible(true);
        }else{probut3.setEnabled(true);}
        
        if(aobj.getSource()==probut4)
        {
            probut4.setEnabled(false);
            playerobj.setprofile(profimg4);
            computerobj.setprofile(compimg);
            confirmbut.setVisible(true);
            sobj.playone("Audio/click.wav");
            uname.setVisible(true);
        }else{probut4.setEnabled(true);}
        
        if(aobj.getSource()==probut5)
        {
            probut5.setEnabled(false);
            playerobj.setprofile(profimg5);
            computerobj.setprofile(compimg);
            confirmbut.setVisible(true);
            sobj.playone("Audio/click.wav");
            uname.setVisible(true);
        }else{probut5.setEnabled(true);}
        
        if(aobj.getSource()==probut6)
        {
            probut6.setEnabled(false);
            playerobj.setprofile(profimg6);
            computerobj.setprofile(compimg);
            confirmbut.setVisible(true);
            sobj.playone("Audio/click.wav");
            uname.setVisible(true);
        }else{probut6.setEnabled(true);}
        
        if(aobj.getSource()==probut7)
        {
            probut7.setEnabled(false);
            playerobj.setprofile(profimg7);
            computerobj.setprofile(compimg);
            confirmbut.setVisible(true);
            sobj.playone("Audio/click.wav");
            uname.setVisible(true);
        }else{probut7.setEnabled(true);}
        
        if(aobj.getSource()==probut8)
        {
            probut8.setEnabled(false);
            playerobj.setprofile(profimg8);
            computerobj.setprofile(compimg);
            confirmbut.setVisible(true);
            sobj.playone("Audio/click.wav");
            uname.setVisible(true);
        }else{probut8.setEnabled(true);}

        if(aobj.getSource()==backbut)
        {
            frame.dispose();
            sobj.playone("Audio/click.wav");
            try
            {
            Select sobj1 = new Select(sobj);
            }
            catch(Exception eobj){}
        }

        if(aobj.getSource() == confirmbut)
        {
            if(uname.getText().length()<1)
            {
                sobj.playone("Audio/error.wav");
                JOptionPane.showMessageDialog(frame,"Username is empty.","Note",JOptionPane.ERROR_MESSAGE);
            }
            else if(uname.getText().length()>8)
            {
                sobj.playone("Audio/error.wav");
                JOptionPane.showMessageDialog(frame,"Username Should Be of 8 Characters.","Note",JOptionPane.ERROR_MESSAGE);
            }
            else if(uname.getText().equals("Computer"))
            {
                sobj.playone("Audio/error.wav");
                JOptionPane.showMessageDialog(frame,"Computer name already taken by Computer.","Note",JOptionPane.ERROR_MESSAGE);
            }
            else
            {
            sobj.playone("Audio/click.wav");
            computerobj.setname("Computer");
            playerobj.setname(uname.getText());
            playerobj.setturnflag(true);
            frame.dispose();
            try
            {
            MainG mobj = new MainG(sobj,playerobj,computerobj);
            }
            catch(Exception eobj){}
            }
        }
    }
}


/***************************************
   in this mode we will ask the user to create 2 profiles as it is 2 player mode 
   every player will be asked to select it's profile and username and the code will check both the names are similar or not,
   profiles can be same but names can't be same as it may create confusion among the users.
   if player1's selected status becomes true then only the program will run forward and will ask for the input from 2nd player other it will give error message.
   for e.g. 1. No Username 
            2. Username should be of 8 character.
            3. username is already taken by computer/player1.
    after all the verification made by the code then further the MainG (Main game) class will get executed.
 ***************************************/
class Mode2 implements ActionListener
{
    JFrame frame;
    ImageIcon bg,profimg1,profimg2,profimg3,profimg4,profimg5,profimg6,profimg7,profimg8,selectimg,backimg,compimg;
    JLabel bglab,profsel,profsel1,selproflab,namelab;
    JTextField uname;

    JButton probut1,probut2,probut3,probut4,probut5,probut6,probut7,probut8,backbut,confirmbut;
    // JButton probut11,probut12,probut13,probut14,probut15,probut16,probut17,probut18;
    
    Sound sobj;
    Player player1obj = new Player();
    Player player2obj = new Player();
    
    //Image img;
    
    Border border = BorderFactory.createLineBorder(Color.white,3);

    public Mode2(Sound sobj1)throws Exception
    {

        // Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        // int width = (int)size.getWidth(); 
        // int height = (int)size.getHeight();
        // img = bg.getImage();
        // img = img.getScaledInstance(width,height,java.awt.Image.SCALE_SMOOTH);
        // bg = new ImageIcon(img);
    
    
        // System.out.println(width);
        // System.out.println(height);


        this.sobj=(Sound)sobj1.clone();
        frame = new JFrame();
        bg = new ImageIcon("Pics/bg2.jpg");
        bglab = new JLabel();
        profsel = new JLabel();
        profsel1 = new JLabel();
        selproflab = new JLabel();
        namelab = new JLabel();

        probut1 =  new JButton();
        probut2 =  new JButton();
        probut3 =  new JButton();
        probut4 =  new JButton();
        probut5 =  new JButton();
        probut6 =  new JButton();
        probut7 =  new JButton();
        probut8 =  new JButton();
        
        uname = new JTextField();
        
        confirmbut =  new JButton();
        
        backbut =  new JButton();

        profimg1 = new ImageIcon("Pics/prof/prof1.png");
        profimg2 = new ImageIcon("Pics/prof/prof2.png");
        profimg3 = new ImageIcon("Pics/prof/prof3.png");
        profimg4 = new ImageIcon("Pics/prof/prof4.png");
        profimg5 = new ImageIcon("Pics/prof/prof5.png");
        profimg6 = new ImageIcon("Pics/prof/prof6.png");
        profimg7 = new ImageIcon("Pics/prof/prof7.png");
        profimg8 = new ImageIcon("Pics/prof/prof8.png");

        ImageIcon setsize[] = {profimg1,profimg2,profimg3,profimg4,profimg5,profimg6,profimg7,profimg8};

        
        backimg = new ImageIcon("Pics/backbut.png");
    
        frame.setSize(815,638);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
        bglab.setBounds(0,0,800,600);
        bglab.setIcon(bg);
        bglab.setOpaque(true);
        bglab.setBackground(Color.black);
    
        for(int i = 0 ; i<8 ; i++)
        {
        Image img;
        img = setsize[i].getImage();
        img = img.getScaledInstance(95,82,java.awt.Image.SCALE_SMOOTH);
        setsize[i] = new ImageIcon(img);
        }

        profsel.setBounds(18,116,261,416);
        profsel.setBackground(new Color(90,61,37));
        profsel.setOpaque(true);
        profsel.setBorder(border);
        
        probut1.setBounds(38,138,95,82);
        probut1.setIcon(setsize[0]);
        probut2.setBounds(163,138,95,82);
        probut2.setIcon(setsize[1]);
        probut3.setBounds(38,235,95,82);
        probut3.setIcon(setsize[2]);
        probut4.setBounds(163,235,95,82);
        probut4.setIcon(setsize[3]);
        probut5.setBounds(38,332,95,82);
        probut5.setIcon(setsize[4]);
        probut6.setBounds(163,332,95,82);
        probut6.setIcon(setsize[5]);
        probut7.setBounds(38,429,95,82);
        probut7.setIcon(setsize[6]);
        probut8.setBounds(163,429,95,82);
        probut8.setIcon(setsize[7]);
        
        uname.setBounds(410,235,220,40);
        uname.setBackground(new Color(90,61,37));
        uname.setForeground(Color.white);
        uname.setHorizontalAlignment(JLabel.CENTER);
        uname.setText("Player 1");
        uname.setFont(new Font("Serif",Font.BOLD,22));
        uname.setBorder(border);
        uname.setVisible(false);

        backbut.setBounds(5,5,51,51);
        backbut.setIcon(backimg);
        
        confirmbut.setBounds(435,345,170,40);
        confirmbut.setBackground(new Color(211,172,123));
        confirmbut.setForeground(Color.black);
        confirmbut.setText("CONFIRM");
        confirmbut.setFont(new Font("Serif",Font.BOLD,26));
        confirmbut.setVisible(false);
        confirmbut.setFocusable(false);
        
        selproflab.setBounds(18,72,261,35);
        selproflab.setBackground(new Color(90,61,37));
        selproflab.setOpaque(true);
        selproflab.setForeground(Color.white);
        selproflab.setHorizontalAlignment(JLabel.CENTER);
        selproflab.setBorder(border);
        selproflab.setText("Select Profile for Player1");
        selproflab.setFont(new Font("Serif",Font.BOLD,22));
        
        namelab.setBounds(370,138,300,50);
        namelab.setBackground(new Color(90,61,37));
        namelab.setOpaque(true);
        namelab.setForeground(Color.white);
        namelab.setHorizontalAlignment(JLabel.CENTER);
        namelab.setBorder(border);
        namelab.setText("Enter Username for Player1");
        namelab.setFont(new Font("Serif",Font.BOLD,22));
        namelab.setVisible(false);

        probut1.addActionListener(this);
        probut2.addActionListener(this);
        probut3.addActionListener(this);
        probut4.addActionListener(this);
        probut5.addActionListener(this);
        probut6.addActionListener(this);
        probut7.addActionListener(this);
        probut8.addActionListener(this);
        confirmbut.addActionListener(this);
        backbut.addActionListener(this);

        frame.add(probut1);
        frame.add(probut2);
        frame.add(probut3);
        frame.add(probut4);
        frame.add(probut5);
        frame.add(probut6);
        frame.add(probut7);
        frame.add(probut8);
        frame.add(confirmbut);
        frame.add(selproflab);
        frame.add(namelab);
        frame.add(uname);
        frame.add(backbut);
        frame.add(profsel);
        frame.add(bglab);
        
        frame.setLayout(null);
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent aobj)
    {   

        if(aobj.getSource()==probut1)
        {
            probut1.setEnabled(false);
            sobj.playone("Audio/click.wav");

            if(player1obj.getselectstat()==false)
            {
            player1obj.setprofile(profimg1);
            namelab.setVisible(true);
            uname.setVisible(true);
            confirmbut.setVisible(true);
            }
            if(player1obj.getselectstat()==true && player2obj.getselectstat()==false)
            {
                player2obj.setprofile(profimg1);
                namelab.setVisible(true);
                uname.setVisible(true);
                confirmbut.setVisible(true);
            }

        }else{probut1.setEnabled(true);}

        if(aobj.getSource()==probut2)
        {
            probut2.setEnabled(false);
            sobj.playone("Audio/click.wav");
            if(player1obj.getselectstat()==false)
            {
            player1obj.setprofile(profimg2);
            namelab.setVisible(true);
            uname.setVisible(true);
            confirmbut.setVisible(true);
            }
            if(player1obj.getselectstat()==true && player2obj.getselectstat()==false)
            {
                player2obj.setprofile(profimg2);
                namelab.setVisible(true);
                uname.setVisible(true);
                confirmbut.setVisible(true);
            }

        }else{probut2.setEnabled(true);}
        
        if(aobj.getSource()==probut3)
        {
            probut3.setEnabled(false);
            sobj.playone("Audio/click.wav");
            if(player1obj.getselectstat()==false)
            {
            player1obj.setprofile(profimg3);
            namelab.setVisible(true);
            uname.setVisible(true);
            confirmbut.setVisible(true);
            }
            if(player1obj.getselectstat()==true && player2obj.getselectstat()==false)
            {
                player2obj.setprofile(profimg3);
                namelab.setVisible(true);
                uname.setVisible(true);
                confirmbut.setVisible(true);
            }
        }else{probut3.setEnabled(true);}
        
        if(aobj.getSource()==probut4)
        {
            probut4.setEnabled(false);
            sobj.playone("Audio/click.wav");
            if(player1obj.getselectstat()==false)
            {
            player1obj.setprofile(profimg4);
            namelab.setVisible(true);
            uname.setVisible(true);
            confirmbut.setVisible(true);
            }
            if(player1obj.getselectstat()==true && player2obj.getselectstat()==false)
            {
                player2obj.setprofile(profimg4);
                namelab.setVisible(true);
                uname.setVisible(true);
                confirmbut.setVisible(true);
            }

        }else{probut4.setEnabled(true);}
        
        if(aobj.getSource()==probut5)
        {
            probut5.setEnabled(false);
            sobj.playone("Audio/click.wav");
            if(player1obj.getselectstat()==false)
            {
            player1obj.setprofile(profimg5);
            namelab.setVisible(true);
            uname.setVisible(true);
            }
            if(player1obj.getselectstat()==true && player2obj.getselectstat()==false)
            {
                player2obj.setprofile(profimg5);
                namelab.setVisible(true);
                uname.setVisible(true);
                confirmbut.setVisible(true);
            }
        }else{probut5.setEnabled(true);}
        
        if(aobj.getSource()==probut6)
        {
            probut6.setEnabled(false);
            sobj.playone("Audio/click.wav");
            if(player1obj.getselectstat()==false)
            {
            player1obj.setprofile(profimg6);
            namelab.setVisible(true);
            uname.setVisible(true);
            confirmbut.setVisible(true);
            }
            if(player1obj.getselectstat()==true && player2obj.getselectstat()==false)
            {
                player2obj.setprofile(profimg6);
                namelab.setVisible(true);
                uname.setVisible(true);
                confirmbut.setVisible(true);
            }
        }else{probut6.setEnabled(true);}
        
        if(aobj.getSource()==probut7)
        {
            probut7.setEnabled(false);
            sobj.playone("Audio/click.wav");
            if(player1obj.getselectstat()==false)
            {
            player1obj.setprofile(profimg7);
            namelab.setVisible(true);
            uname.setVisible(true);
            confirmbut.setVisible(true);
            }
            if(player1obj.getselectstat()==true && player2obj.getselectstat()==false)
            {
                player2obj.setprofile(profimg7);
                namelab.setVisible(true);
                uname.setVisible(true);
                confirmbut.setVisible(true);
            }

        }else{probut7.setEnabled(true);}
        
        if(aobj.getSource()==probut8)
        {
            probut8.setEnabled(false);
            sobj.playone("Audio/click.wav");
            if(player1obj.getselectstat()==false)
            {
            player1obj.setprofile(profimg8);
            namelab.setVisible(true);
            uname.setVisible(true);
            confirmbut.setVisible(true);
            }
            if(player1obj.getselectstat()==true && player2obj.getselectstat()==false)
            {
                player2obj.setprofile(profimg8);
                namelab.setVisible(true);
                uname.setVisible(true);
                confirmbut.setVisible(true);
            }
        }else{probut8.setEnabled(true);}

        if(aobj.getSource()==confirmbut)
        {
           sobj.playone("Audio/click.wav");
           if(player1obj.getselectstat()==true && player2obj.getselectstat()==false)
           {
                if(uname.getText().length()<1)
                {
                    sobj.playone("Audio/click.wav");
                    JOptionPane.showMessageDialog(frame,"Username is empty","Note",JOptionPane.ERROR_MESSAGE);
                }
                else if(uname.getText().length()>8)
                {
                    sobj.playone("Audio/click.wav");
                    JOptionPane.showMessageDialog(frame,"Username Should be of 8 Characters","Note",JOptionPane.ERROR_MESSAGE);
                }
                else if(uname.getText().equals("Computer"))
                {
                    sobj.playone("Audio/click.wav");
                    JOptionPane.showMessageDialog(frame,"Computer name already taken by Computer","Note",JOptionPane.ERROR_MESSAGE);
                }
                else if(uname.getText().equals(player1obj.getname()))
                {
                    sobj.playone("Audio/click.wav");
                    JOptionPane.showMessageDialog(frame,player1obj.getname()+" name already taken by Player 1","Note",JOptionPane.ERROR_MESSAGE);
                }

                else
                {
                    player2obj.setselect(true);
                    player2obj.setname(uname.getText());
                    frame.dispose();
                    try
                     {
                     player1obj.setturnflag(true);
                     player2obj.setturnflag(false);
                     MainG mobj = new MainG(sobj,player1obj,player2obj);
                     }
                     catch(Exception eobj){}
                }

           }

           if(player1obj.getselectstat()==false)
           {
            if(uname.getText().length()<1)
            {
                JOptionPane.showMessageDialog(frame,"Username is empty","Note",JOptionPane.ERROR_MESSAGE);
            }
            else if(uname.getText().length()>8)
            {
                JOptionPane.showMessageDialog(frame,"Username Should be of 8 Characters","Note",JOptionPane.ERROR_MESSAGE);
            }
            else
            {
                uname.setVisible(false);
                namelab.setVisible(false);
                confirmbut.setVisible(false);
                player1obj.setname(uname.getText());
                uname.setText("Player 2");
                namelab.setText("Enter Username for Player 2");
                selproflab.setText("Select Profile for Player 2");
                selproflab.setBounds(521,72,261,35);
                namelab.setBounds(80,138,300,50);
                profsel.setBounds(521,116,261,416);
                probut1.setBounds(541,138,95,82);
                probut2.setBounds(666,138,95,82);
                probut3.setBounds(541,235,95,82);
                probut4.setBounds(666,235,95,82);
                probut5.setBounds(541,332,95,82);
                probut6.setBounds(666,332,95,82);
                probut7.setBounds(541,429,95,82);
                probut8.setBounds(666,429,95,82);
                uname.setBounds(120,235,220,40);
                confirmbut.setBounds(150,345,170,40);
                player1obj.setselect(true);
            }
           }
        }

        if(aobj.getSource()==backbut)
        {
            frame.dispose();
            sobj.playone("Audio/click.wav");
            try
            {
            Select sobj1 = new Select(sobj);
            }
            catch(Exception eobj){}
        }
    }
}

/***************************************
  MainG Class
  In this class, all the game's actions and conditions are checked and according to that the game will run.
  It has 6 timer each performing their own function accordingly when they are called by using timername.start().

  Timer
   timer = 10 sec timer to answer.
   waittimer = to show user the answer is correct or wrong, if wrong which one is correct so this is 2 secs timer.
   comptime = this will give the computer 2 secs of time to process the answer of a question which is asked to it.
   changeturn = this timer is created just to change the turn among the players.
   check =  this timer will check whether the player is on ladder or snake. this timer will get completed in 1 millisecond.
   winnertimer = this timer is of 3 secs and will tell which player has won the game and will call the Winner class's constructor by initialising the it's object.

   Methods 
    playturn = this method will create a quiz from the QuizGen user defined library/Package and will display the question in the quizlabel1 i.e the left hand side quiz white box for player 1 if the turnflag for player1 is true if not true then the question will be displayed in the quizlabel2 i.e situated on the right hand side for 2nd player.for 2 player mode.

    compturn = this method will be called only if the mode 1 is selected in this all the processing and quiz generation and decision taken by computer whether to give right answer or wrong answer happens in this method and it's correlated timer which is named as comptimer.
   
    The rolling of dice is done by using simple array containing variables of data-type ImageIcon from which the pc will random select 1 image and will display it on the screen the same number will be added to player's current position.
   
   Pause Button - it will stop the game temporarily making the getquiz button or the roller button disappear and will give you 3 options as below:
     1. Resume = will resume the game, by again making the getquiz or roller button visible on screen.
     2. Restart =  will restart the game setting the players score and question asked to 0 and there places to 1.
     3. Quit =  will terminate the user from current game and will take him/her back to the select screen.

    For all the randomly choosing action we used java's in-built random function.
 ***************************************/
class MainG implements ActionListener
{
    JFrame frame;
    JLabel player1label,complabel,boardlabel,namelabel1,namelabel2,quizlabel1,quizlabel2,timelabel,Yougot,pausemenu;
    JLabel comptext;
    JLabel score;

    JLabel winlab = new JLabel();

    int rollerflag = 0;
    int compflag = 0;

    JButton pause,closebut,resumebut,restartbut,quitbut;

    int sec = 10;

    JButton getquiz;

    ImageIcon boardimg = new ImageIcon("Pics/Boards/board1.png");

    Border border = BorderFactory.createLineBorder(Color.white,3);
    Border blackborder = BorderFactory.createLineBorder(Color.black,3);
    
    JButton but1,but2,but3,but4;
    JButton option[]= {but1,but2,but3,but4};


    QuizGen compquiz = new QuizGen();

    ImageIcon img1,img2,img3,img4,img5,img6;
    ImageIcon dice[] = {img1,img2,img3,img4,img5,img6};
    JButton roller = new JButton();

    Sound sobj;
    Player player1obj,player2obj;
    Database dobj;
    
    JLabel p1,p2;
    ImageIcon p1img,p2img;

    Random rand = new Random();
    int randno;
    String ans;
    String quizcomp;

    boolean flagopt;

    Timer timer = new Timer(1000,new ActionListener()
    {
        String second_string=String.format("%02d",sec);
            public void actionPerformed(ActionEvent e)
            {   
              if(sec>0)
              {
                timelabel.setVisible(true);
                sec--;
                second_string=String.format("%02d",sec);
                timelabel.setText("<html>Time<br>"+second_string);
              }
              else if(sec==0 && player2obj.getname().equals("Computer")) //## MODE1 SATI PLAYER 1 MISSES TO ANSWER IN TIME..
              {
                Yougot.setVisible(true);
                Yougot.setText("Time Up!!");
                timelabel.setVisible(false);
                timer.stop();
                quizlabel1.setText("Quiz");
                option[0].setVisible(false);
                option[1].setVisible(false);
                option[2].setVisible(false);
                option[3].setVisible(false);
                compturn();
              }

              //ELSE IF SEC ==0 AND MODE2 SATI PLAYER 1 MISSES TO ANSWER IN TIME..
              else if(sec==0 && (player2obj.getname().equals("Computer")==false) && player1obj.getturnflag()==true) 
              {
                Yougot.setVisible(true);
                Yougot.setText("Time Up!!");
                timelabel.setVisible(false);
                timelabel.setBounds(654,528,115,60);
                timer.stop();
                quizlabel1.setText("Quiz");
                option[0].setVisible(false);
                option[1].setVisible(false);
                option[2].setVisible(false);
                option[3].setVisible(false);
                getquiz.setBounds(667,296,107,32);
                getquiz.setVisible(true);
                player1obj.setturnflag(false);
                player2obj.setturnflag(true);
              }

              //ELSE IF SEC ==0 AND MODE2 SATI PLAYER 2 MISSES TO ANSWER IN TIME..
              else if(sec==0 && (player2obj.getname().equals("Computer")==false) && player2obj.getturnflag()==true) 
              {
                Yougot.setVisible(true);
                Yougot.setText("Time Up!!");
                timelabel.setBounds(25,528,115,60);
                timelabel.setVisible(false);
                timer.stop();
                quizlabel2.setText("Quiz");
                option[0].setVisible(false);
                option[1].setVisible(false);
                option[2].setVisible(false);
                option[3].setVisible(false);
                getquiz.setBounds(25,296,107,32);
                getquiz.setVisible(true);
                player1obj.setturnflag(true);
                player2obj.setturnflag(false);
              }

            }
    });

    Timer waitimer = new Timer(1000,new ActionListener()
    {
        public void actionPerformed(ActionEvent eobj)
        {
            if(sec>0)
            {
                sec--;

            }
            else if(sec==0 && flagopt==true && player2obj.getname().equals("Computer"))  //## MODE 1 MDHE PLAYER 1 CH BROBRR ANSWER ASLYAVRR
            {
                option[0].setVisible(false);                
                option[1].setVisible(false);                
                option[2].setVisible(false);
                option[3].setVisible(false);
                player1obj.setcorrectans(1);
                score.setText("<HTML>| SCORE |<BR/>"+"|| "+player1obj.getcorrectans()+"   ||   "+player2obj.getcorrectans()+" ||</HTML>");
                roller.setVisible(true);
                pause.setVisible(true);
                waitimer.stop();
            }

            else if (sec==0 && flagopt==true && player1obj.getturnflag()==true)   //## MODE 2 MDHE PLAYER 1 CH BROBRR ANSWER ASLYAVRR
            {
                option[0].setVisible(false);                
                option[1].setVisible(false);                
                option[2].setVisible(false);
                option[3].setVisible(false);
                player1obj.setcorrectans(1);
                score.setText("<HTML>| SCORE |<BR/>"+"|| "+player1obj.getcorrectans()+"   ||   "+player2obj.getcorrectans()+" ||</HTML>");
                roller.setBounds(35,305,81,81);
                roller.setVisible(true);
                pause.setVisible(true);
                waitimer.stop();
            }

            else if (sec==0 && flagopt==true && player2obj.getturnflag()==true)   //## MODE 2 MDHE PLAYER 2 CH BROBRR ANSWER ASLYAVRR
            {
                option[0].setVisible(false);                
                option[1].setVisible(false);                
                option[2].setVisible(false);
                option[3].setVisible(false);
                player2obj.setcorrectans(1);
                score.setText("<HTML>| SCORE |<BR/>"+"|| "+player1obj.getcorrectans()+"   ||   "+player2obj.getcorrectans()+" ||</HTML>");
                roller.setBounds(677,305,81,81);
                roller.setVisible(true);
                pause.setVisible(true);
                waitimer.stop();
            }


            else if(sec==0 && flagopt==false && player2obj.getname().equals("Computer"))  //## MODE 1 MDHE PLAYER 1 CH CHUKLYAVRR ANSWER
            {
                option[0].setVisible(false);                
                option[1].setVisible(false);                
                option[2].setVisible(false);
                option[3].setVisible(false);
                quizlabel1.setText("Quiz");
                pause.setVisible(true);
                waitimer.stop();
                
                compturn();
            }

            else if(sec==0 && flagopt==false && player1obj.getturnflag()==true)  // ## MODE 2 MDHE PLAYER 1 CH CHUKLYAVRRR ANSWER
            {
                option[0].setVisible(false);
                option[1].setVisible(false);
                option[2].setVisible(false);
                option[3].setVisible(false);
                timelabel.setBounds(654,528,115,60);
                player1obj.setturnflag(false);
                player2obj.setturnflag(true);
                quizlabel1.setText("Quiz");
                pause.setVisible(true);
                getquiz.setBounds(667,296,107,32);
                getquiz.setVisible(true);
                waitimer.stop();
            }
            else if(sec==0 && flagopt==false && player2obj.getturnflag()==true)  // ## MODE 2 MDHE PLAYER 2 CH CHUKLYAVRRR ANSWER
            {
                
                option[0].setVisible(false);
                option[1].setVisible(false);
                option[2].setVisible(false);
                option[3].setVisible(false);
                timelabel.setBounds(25,528,115,60);
                player2obj.setturnflag(false);
                player1obj.setturnflag(true);
                quizlabel2.setText("Quiz");
                pause.setVisible(true);
                getquiz.setBounds(25,296,107,32);
                getquiz.setVisible(true);
                waitimer.stop();
            }
                
            }
            
        }
    );

     Timer comptime = new Timer(1000,new ActionListener()
    {

        public void actionPerformed(ActionEvent eobj)
        {
            if(sec>0)
            {
                sec--;
                timelabel.setBounds(654,528,115,60);
                String second_string=String.format("%02d",sec);
                timelabel.setText("<html>Time<br>"+second_string);
                timelabel.setVisible(true);
                
            }
            else
            {
                if(compquiz.getcompturn()==true)
                {  
                    quizlabel2.setText("Quiz");
                    quizlabel2.setText("<html>"+quizlabel2.getText()+"<br/>"+quizcomp+"="+ans+"</html>");
                    Random rand = new Random();
                    int cmove = rand.nextInt(6)+1;
                    player2obj.setplace(player2obj.getplace()+cmove);
                    check.start();
                    // cord cobj = new cord(player2obj.getplace());
                    // p2.setBounds(cobj.getp2x(),cobj.getp2y(),26,40);
                    comptext.setText("<html>Computer<br/>Answered<br/>Correctly<br/>Computer Got<br/>  "+cmove+"</html>");
                    if(cmove==6)
                    {
                        cmove = rand.nextInt(6)+1;
                        player2obj.setplace(player2obj.getplace()+cmove);
                        check.start();
                        // cord cobj1 = new cord(player2obj.getplace());
                        // p2.setBounds(cobj1.getp2x(),cobj1.getp2y(),26,40);
                        comptext.setText("<html>Computer<br/>Rolled dice<br/>Twice<br/>Computer Got<br/>6 & "+cmove+"</html>");
                    }
                    roller.setVisible(false);
                    Yougot.setVisible(false);
                    player2obj.setcorrectans(1);
                    score.setText("<HTML>| SCORE |<BR/>"+"|| "+player1obj.getcorrectans()+"   ||   "+player2obj.getcorrectans()+" ||</HTML>");
                    timelabel.setVisible(false);
                    compflag--;
                }
                else
                {
                    comptext.setText("<html>Computer<br/>  Got<br/>Wrong<br/>"+ans+"</html>");//We hope you got it ryt answer is ...whatever it will be.
                    roller.setVisible(false);
                    Yougot.setVisible(false);
                    timelabel.setVisible(false);
                    compflag--;
                }
                quizlabel1.setText("Quiz");
                getquiz.setVisible(true);
                option[0].setEnabled(true);
                option[1].setEnabled(true);
                option[2].setEnabled(true);
                option[3].setEnabled(true);
                timelabel.setBounds(25,510,115,60);
                comptime.stop();
            }
        }
    });

    Timer changeturn = new Timer(1000,new ActionListener()
    {
        int sec=1;
        public void actionPerformed(ActionEvent aobj)
        {
            if(sec>0)
            {
                sec--;
            }
            else if(sec==0 && player1obj.getturnflag()==true)
            {
                timelabel.setBounds(654,528,115,60);
                roller.setVisible(false);
                quizlabel1.setText("Quiz");
                getquiz.setBounds(667,296,107,32);
                getquiz.setVisible(true);
                player1obj.setturnflag(false);
                player2obj.setturnflag(true);
                Yougot.setVisible(false);
                rollerflag--;
                changeturn.stop();
            }
            else if(sec==0 && player2obj.getturnflag()==true)
            {
                timelabel.setBounds(25,510,115,60);
                roller.setVisible(false);
                quizlabel2.setText("Quiz");
                getquiz.setBounds(25,296,107,32);
                getquiz.setVisible(true);
                player1obj.setturnflag(true);
                player2obj.setturnflag(false);
                Yougot.setVisible(false);
                rollerflag--;
                changeturn.stop();
            }
        }
    }
    );

    Timer check = new Timer(100,new ActionListener()
    {
        int ladder [] = {7,21,31,34,54,63};
        int up [] = {36,58,51,84,89,82};
        int snake [] = {33,43,56,66,78,96};
        int down [] = {5,24,20,12,59,72};
        int sec=1;

        public void actionPerformed(ActionEvent aobj)
        {
            if(sec>0)
            {
                sec--;
            }
            else if(sec==0)
            {
                if(player1obj.getturnflag()==true)
                {
                    for(int i = 0; i<6 ; i++)
                    {
                        if(player1obj.getplace()==ladder[i])
                        {
                            player1obj.setplace(up[i]);
                            sobj.playone("Audio/climb.wav");
                        }
                        if(player1obj.getplace()==snake[i])
                        {
                            player1obj.setplace(down[i]);
                            sobj.playone("Audio/snake.wav");
                        }
                    }
                    cord cobj = new cord(player1obj.getplace());
                    p1.setBounds(cobj.getp1x(),cobj.getp1y(),26,40);
                    check.stop();

                }
                if(player2obj.getturnflag()==true)
                {
                    for(int i = 0; i<6 ; i++)
                    {
                        if(player2obj.getplace()==ladder[i])
                        {
                            player2obj.setplace(up[i]);
                            sobj.playone("Audio/climb.wav");
                        }
                        if(player2obj.getplace()==snake[i])
                        {
                            player2obj.setplace(down[i]);
                            sobj.playone("Audio/snake.wav");
                        }
                    }
                    cord cobj = new cord(player2obj.getplace());
                    p2.setBounds(cobj.getp2x(),cobj.getp2y(),26,40);
                    check.stop();
                }
                if(player2obj.getname().equals("Computer"))
                {
                    for(int i = 0; i<6 ; i++)
                    {
                        if(player2obj.getplace()==ladder[i])
                        {
                            player2obj.setplace(up[i]);
                            sobj.playone("Audio/climb.wav");
                        }
                        if(player2obj.getplace()==snake[i])
                        {
                            player2obj.setplace(down[i]);
                            sobj.playone("Audio/snake.wav");
                        }
                    }
                    cord cobj = new cord(player2obj.getplace());
                    p2.setBounds(cobj.getp2x(),cobj.getp2y(),26,40);
                    check.stop();
                }

            }
        }
    }
    );

    Timer winnertimer = new Timer(1000,new ActionListener()
    {
        int sec = 3;

        public void actionPerformed(ActionEvent aobj)
        {
        if(sec>0)
        {
           
            sec--;
            if(player1obj.getturnflag()==true)
            {winlab.setText("<html>Congralution<br/>"+player1obj.getname()+"<br/>You Won</html>");}
            else if(player2obj.getturnflag()==true)
            {winlab.setText("<html>Congralution<br/>"+player2obj.getname()+"<br/>You Won</html>");}
            winlab.setVisible(true);
        }

        else
        {
            frame.dispose();
            winnertimer.stop();
            if(player1obj.getturnflag()==true)
            {
                Winning wobj = new Winning(sobj,player1obj);
            }
            else if(player2obj.getturnflag()==true)
            {
                Winning wobj = new Winning(sobj,player2obj);
            }
        }
        }
    });
    
    public MainG(Sound sobj1, Player playerobj1, Player computerobj1)  //CONSTRUCTOR
    {
        try{
        this.player1obj = (Player)playerobj1.clone();
        this.player2obj = (Player)computerobj1.clone();
        this.sobj = (Sound)sobj1.clone();
        }
        catch(Exception eobj){}

        frame = new JFrame();
        player1label = new JLabel();
        complabel = new JLabel();
        boardlabel = new JLabel();
        namelabel1 = new JLabel();
        namelabel2 = new JLabel();
        quizlabel1 = new JLabel();
        quizlabel2 = new JLabel();
        timelabel = new JLabel();
        score = new JLabel();
        Yougot = new JLabel();
        comptext=new JLabel();
        pausemenu=new JLabel();
        p1 = new JLabel();
        p2 = new JLabel();
        pause = new JButton();
        resumebut = new JButton();
        restartbut = new JButton();
        quitbut = new JButton();

        ImageIcon p1img = new ImageIcon("Pics/Pieces/p1.png");
        ImageIcon p2img = new ImageIcon("Pics/Pieces/p2.png");
        ImageIcon pauseimg = new ImageIcon("Pics/pausemenu.png");
        ImageIcon resume = new ImageIcon("Pics/resume.png");
        ImageIcon restart = new ImageIcon("Pics/restart.png");
        ImageIcon quit = new ImageIcon("Pics/quit.png");

        p1.setBounds(176,443,26,40);
        p2.setBounds(176+15,443,26,40);

        p1.setIcon(p1img);
        p2.setIcon(p2img);

        getquiz = new JButton("Get Quiz");
        option[0] = new JButton();
        option[1] = new JButton();
        option[2] = new JButton();
        option[3] = new JButton();

        frame.setSize(815,640);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setBackground(new Color(242,158,68));

        player1label.setBounds(12,20,136,117);
        player1label.setIcon(player1obj.getprofile());
        
        complabel.setBounds(654,20,136,117);
        complabel.setIcon(player2obj.getprofile());
        
        boardlabel.setBounds(162,20,476,476);
        boardlabel.setIcon(boardimg);
        
        namelabel1.setBounds(12,149,133,46);
        namelabel1.setBackground(new Color(90,61,37));
        namelabel1.setBorder(border);
        namelabel1.setOpaque(true);
        namelabel1.setText(player1obj.getname());
        namelabel1.setFont(new Font("Serif",Font.BOLD,22));
        namelabel1.setHorizontalAlignment(JLabel.CENTER);
        namelabel1.setForeground(Color.white);
        
        namelabel2.setBounds(654,149,133,46);
        namelabel2.setBackground(new Color(90,61,37));
        namelabel2.setBorder(border);
        namelabel2.setOpaque(true);
        namelabel2.setText(player2obj.getname());
        namelabel2.setFont(new Font("Serif",Font.BOLD,22));
        namelabel2.setHorizontalAlignment(JLabel.CENTER);
        namelabel2.setForeground(Color.white);

        score.setBounds(350,495,115,60);
        score.setText("<HTML>| SCORE |<BR/>"+"|| "+player1obj.getcorrectans()+"   ||   "+player2obj.getcorrectans()+" ||</HTML>");
        score.setFont(new Font("Serif",Font.BOLD,22));
        score.setHorizontalAlignment(JLabel.CENTER);
        score.setForeground(Color.black);

        pause.setBounds(350,565,115,30);
        pause.setText("Pause");
        pause.setFont(new Font("Serif",Font.BOLD,16));
        pause.setHorizontalAlignment(JButton.CENTER);
        pause.setFocusable(false);
        pause.setForeground(Color.black);

        resumebut.setBounds(315,160,200,80);
        resumebut.setIcon(resume);
        resumebut.setFocusable(false);
        resumebut.setVisible(false);
        
        restartbut.setBounds(315,260,200,80);
        restartbut.setIcon(restart);
        restartbut.setFocusable(false);
        restartbut.setVisible(false);
        
        quitbut.setBounds(315,360,200,80);
        quitbut.setIcon(quit);
        quitbut.setFocusable(false);
        quitbut.setVisible(false);
        
        pausemenu.setBounds(0,0,800,600);
        pausemenu.setIcon(pauseimg);
        pausemenu.setVisible(false);

        winlab.setBounds(115,50,589,500);
        winlab.setBackground(new Color(90,61,37));
        winlab.setForeground(Color.white);
        winlab.setOpaque(true);
        winlab.setFont(new Font("Serif",Font.BOLD,34));
        winlab.setBorder(border);
        winlab.setHorizontalAlignment(JLabel.CENTER);
        winlab.setVisible(false);

        quizlabel1.setBounds(12,209,133,290);
        quizlabel1.setBackground(Color.white);
        quizlabel1.setBorder(blackborder);
        quizlabel1.setOpaque(true);
        quizlabel1.setText("Quiz");
        quizlabel1.setHorizontalAlignment(JLabel.CENTER);
        quizlabel1.setVerticalAlignment(JLabel.TOP);
        quizlabel1.setFont(new Font("Serif",Font.BOLD,24));
        quizlabel1.setForeground(Color.black);
        
        quizlabel2.setBounds(654,209,133,290);
        quizlabel2.setBackground(Color.white);
        quizlabel2.setBorder(blackborder);
        quizlabel2.setOpaque(true);
        quizlabel2.setText("Quiz");
        quizlabel2.setHorizontalAlignment(JLabel.CENTER);
        quizlabel2.setVerticalAlignment(JLabel.TOP);
        quizlabel2.setFont(new Font("Serif",Font.BOLD,24));
        quizlabel2.setForeground(Color.black);

        getquiz.setBounds(25,296,107,32);
        getquiz.setHorizontalAlignment(JButton.CENTER);
        getquiz.setForeground(Color.black);
        getquiz.setFocusable(false);
        
        option[0].setBounds(25,296,107,32);
        option[0].setHorizontalAlignment(JButton.CENTER);
        option[0].setBackground(new Color(181,226,255));
        option[0].setForeground(Color.black);
        option[0].setFont(new Font("Serif",Font.BOLD,24));
        option[0].setFocusable(false);
        option[0].setVisible(false);
        
        for(int i = 1 ;i<=3;i++)
        {
        option[i].setBounds(25,296+(32*i)+(10*i),107,32);
        option[i].setHorizontalAlignment(JButton.CENTER);
        option[i].setFont(new Font("Serif",Font.BOLD,24));
        option[i].setForeground(Color.black);
        option[i].setBackground(new Color(181,226,255));
        option[i].setFocusable(false);
        option[i].setVisible(false);
        }

        dice[0]=new ImageIcon("Pics/Dice/d1.png");
        dice[1]=new ImageIcon("Pics/Dice/d2.png");
        dice[2]=new ImageIcon("Pics/Dice/d3.png");
        dice[3]=new ImageIcon("Pics/Dice/d4.png");
        dice[4]=new ImageIcon("Pics/Dice/d5.png");
        dice[5]=new ImageIcon("Pics/Dice/d6.png");

        roller.setBounds(35,305,81,81);
        roller.setIcon(dice[0]);
        roller.setFocusable(false);
        roller.setVisible(false);

        Yougot.setBounds(12,400,133,100);
        Yougot.setBackground(Color.white);
        Yougot.setHorizontalAlignment(JLabel.CENTER);
        Yougot.setFont(new Font("Serif",Font.BOLD,24));
        Yougot.setForeground(Color.black);
        Yougot.setVisible(false);

        timelabel.setBounds(25,510,115,60);
        timelabel.setHorizontalAlignment(JLabel.CENTER);
        timelabel.setFont(new Font("serif",Font.BOLD,20));
        timelabel.setForeground(Color.black);
        timelabel.setVisible(false);

        getquiz.addActionListener(this);
        roller.addActionListener(this);
        pause.addActionListener(this);
        resumebut.addActionListener(this);
        restartbut.addActionListener(this);
        quitbut.addActionListener(this);

        option[0].addActionListener(this);
        option[1].addActionListener(this);
        option[2].addActionListener(this);
        option[3].addActionListener(this);

        frame.add(winlab);
        frame.add(resumebut);
        frame.add(restartbut);
        frame.add(quitbut);
        frame.add(pausemenu);
        frame.add(player1label);
        frame.add(complabel);
        frame.add(p1);
        frame.add(p2);
        frame.add(score);
        frame.add(pause);
        frame.add(boardlabel);
        frame.add(namelabel1);
        frame.add(namelabel2);
        frame.add(getquiz);
        frame.add(roller);
        frame.add(option[0]);
        frame.add(option[1]);
        frame.add(option[2]);
        frame.add(option[3]);
        frame.add(timelabel);
        frame.add(Yougot);
        frame.add(comptext);
        frame.add(quizlabel1);
        frame.add(quizlabel2);

        frame.setLayout(null);
        frame.setVisible(true);
    }

    //TURN WISE METHODS FOR FRONT END DISPLAY
    
    public void playturn()
    {
        randno= rand.nextInt(4);
        getquiz.setVisible(false);
        QuizGen quiz = new QuizGen();
        String question = quiz.getquiz();
        ans = Integer.toString(quiz.getans());
        System.out.println(question);
        System.out.println(ans);
        if(player1obj.getturnflag()==true)
        {quizlabel1.setText("<html>"+quizlabel1.getText()+"<br>"+question+"</html>");}
        else if(player2obj.getturnflag()==true)
        {quizlabel2.setText("<html>"+quizlabel2.getText()+"<br>"+question+"</html>");}

        for(int i = 0;i<4;i++)
        {
            if(i==0)
            {
                option[randno].setText(ans);
            }
            if(i!=randno)
            {
                option[i].setText(Integer.toString(quiz.getrand()));

            }
        }
        option[0].setVisible(true);
        option[1].setVisible(true);
        option[2].setVisible(true);
        option[3].setVisible(true);
        this.sec=10;
        timer.start();
    }
    
    public void compturn()
    {
        option[0].setVisible(false);
        option[1].setVisible(false);
        option[2].setVisible(false);
        option[3].setVisible(false);
        QuizGen compquiz = new QuizGen();
        // boolean decision = compquiz.getcompturn();
        this.quizcomp = compquiz.getquiz();
        quizlabel2.setText("Quiz");
        quizlabel2.setText("<html>"+quizlabel2.getText()+"<br/>"+quizcomp+"</html>");
        ans = Integer.toString(compquiz.getans());
        comptext.setText("<html>Processing<br/>Answer..</html>");
        comptext.setBounds(655,250,133,200);
        comptext.setForeground(Color.black);
        comptext.setHorizontalAlignment(JLabel.CENTER);
        comptext.setFont(new Font("Serif",Font.BOLD,20));
        this.sec=3;
        compflag++;
        comptime.start();
    }

    public void actionPerformed(ActionEvent aobj)
    {
        if(aobj.getSource()==resumebut)
        {

            if(rollerflag == 0 && compflag==0)
            {
                getquiz.setVisible(true);
            }
            else if(rollerflag == 1)
            {
                roller.setVisible(true);
            }
            else if(compflag==1)
            {
                compflag--;
                compturn();
            }
            
            sobj.playone("Audio/click.wav");
            pause.setVisible(true);
            pausemenu.setVisible(false);
            resumebut.setVisible(false);
            restartbut.setVisible(false);
            quitbut.setVisible(false);
        }

        if(aobj.getSource()==restartbut)
        {
            sobj.playone("Audio/click.wav");
            pausemenu.setVisible(false);
            resumebut.setVisible(false);
            restartbut.setVisible(false);
            quitbut.setVisible(false);
            pause.setVisible(true);
            player1obj.setplace(1);
            player2obj.setplace(1);
            player1obj.setturnflag(true);
            player2obj.setturnflag(false);
            player1obj.resetcorrectans(0);
            player2obj.resetcorrectans(0);
            player1obj.resetquestno(0);
            player2obj.resetquestno(0);
            getquiz.setVisible(true);
            cord cobj = new cord(player1obj.getplace());
            p1.setBounds(cobj.getp1x(),cobj.getp1y(),26,40);
            p2.setBounds(cobj.getp2x(),cobj.getp2y(),26,40);
            score.setText("<HTML>| SCORE |<BR/>"+"|| "+player1obj.getcorrectans()+"   ||   "+player2obj.getcorrectans()+" ||</HTML>");
            quizlabel2.setText("Quiz");
            Yougot.setVisible(false);
            roller.setVisible(false);
            quizlabel1.setText("Quiz");
            comptext.setText("");
        }
        
        if(aobj.getSource()==quitbut)
        {
            sobj.playone("Audio/click.wav");
            frame.dispose();
            try
            {
            Select sobj1 = new Select(sobj);
            }
            catch(Exception eobj){}
        }

        if(aobj.getSource()==pause)
        {
            if(rollerflag == 1)
            {
                roller.setVisible(false);
            }
            if(compflag == 1)
            {
                comptime.stop();
            }
            sobj.playone("Audio/click.wav");
            pause.setVisible(false);
            getquiz.setVisible(false);
            pausemenu.setVisible(true);
            resumebut.setVisible(true);
            restartbut.setVisible(true);
            quitbut.setVisible(true);
        }

        if(aobj.getSource()==getquiz)
        {
           sobj.playone("Audio/twinkle.wav");
           Yougot.setVisible(false);
           option[0].setEnabled(true);
           option[1].setEnabled(true);
           option[2].setEnabled(true);
           option[3].setEnabled(true);
           option[0].setBackground(new Color(181,226,255));
           option[1].setBackground(new Color(181,226,255));
           option[2].setBackground(new Color(181,226,255));
           option[3].setBackground(new Color(181,226,255));
           pause.setVisible(false);

           if(player1obj.getturnflag()==true) //Applicable for mode 2 and mode 1 both
           {
            option[0].setBounds(25,296,107,32);
            option[1].setBounds(25,338,107,32);
            option[2].setBounds(25,380,107,32);
            option[3].setBounds(25,422,107,32);   
            Yougot.setBounds(12,400,133,100);
            player1obj.setquestno(1);
           }
           else if(player2obj.getturnflag()==true)
           {
            option[0].setBounds(667,296,107,32);
            option[1].setBounds(667,338,107,32);
            option[2].setBounds(667,380,107,32);
            option[3].setBounds(667,422,107,32);
            Yougot.setBounds(654,400,133,100);
            player2obj.setquestno(1);
           }
           playturn();
        }

        if(aobj.getSource()==option[0])
        {
            if(option[0].getText().equals(ans))
            {
                sobj.playone("Audio/correct.wav");
                timer.stop();
                timelabel.setVisible(false);
                option[0].setEnabled(false);
                option[0].setBackground(Color.green);
                option[1].setEnabled(false);                
                option[2].setEnabled(false);
                option[3].setEnabled(false);
                roller.setEnabled(true);
                rollerflag++;
                this.sec = 1;
                this.flagopt=true;
                waitimer.start();
            }
            else
            {
                sobj.playone("Audio/Wrong.wav");
                timer.stop();
                timelabel.setVisible(false);
                option[0].setBackground(Color.red);
                option[randno].setBackground(Color.green);
                option[1].setEnabled(false);                
                option[2].setEnabled(false);
                option[3].setEnabled(false);
                this.sec = 1;
                this.flagopt=false;
                waitimer.start();
            }
        }
         if(aobj.getSource()==option[1])
        {
            if(option[1].getText().equals(ans))
            {
                sobj.playone("Audio/correct.wav");
                timer.stop();
                timelabel.setVisible(false);
                option[1].setEnabled(false);
                option[1].setBackground(Color.green);
                option[0].setEnabled(false);                
                option[2].setEnabled(false);
                option[3].setEnabled(false);
                roller.setEnabled(true);
                rollerflag++;
                this.sec = 1;
                this.flagopt=true;
                waitimer.start();
            }
            else
            {
                sobj.playone("Audio/Wrong.wav");
                timer.stop();
                timelabel.setVisible(false);
                option[1].setEnabled(false);
                option[1].setBackground(Color.red);
                option[randno].setBackground(Color.green);
                option[0].setEnabled(false);                
                option[2].setEnabled(false);
                option[3].setEnabled(false);
                this.sec = 1;
                this.flagopt=false;
                waitimer.start();
            }
        }
        if(aobj.getSource()==option[2])
        {
            if(option[2].getText().equals(ans))
            {
                sobj.playone("Audio/correct.wav");
                timer.stop();
                timelabel.setVisible(false);
                option[2].setEnabled(false);
                option[2].setBackground(Color.green);
                option[0].setEnabled(false);                
                option[1].setEnabled(false);
                option[3].setEnabled(false);
                roller.setEnabled(true);
                rollerflag++;
                this.sec = 1;
                this.flagopt=true;
                waitimer.start();
            }
            else
            {
                sobj.playone("Audio/Wrong.wav");
                timer.stop();
                timelabel.setVisible(false);
                option[2].setEnabled(false);
                option[2].setBackground(Color.red);
                option[randno].setBackground(Color.green);
                option[0].setEnabled(false);                
                option[1].setEnabled(false);
                option[3].setEnabled(false);
                this.sec = 1;
                this.flagopt=false;
                waitimer.start();
            }
        }
        if(aobj.getSource()==option[3])
        {
            if(option[3].getText().equals(ans))
            {
                sobj.playone("Audio/correct.wav");
                timer.stop();
                timelabel.setVisible(false);
                option[3].setEnabled(false);
                option[3].setBackground(Color.green);
                option[0].setEnabled(false);                
                option[2].setEnabled(false);
                option[1].setEnabled(false);
                roller.setEnabled(true);
                rollerflag++;
                this.sec = 1;
                this.flagopt=true;
                waitimer.start();
            }
            else
            {
                sobj.playone("Audio/Wrong.wav");
                timer.stop();
                timelabel.setVisible(false);
                option[3].setEnabled(false);
                option[3].setBackground(Color.red);
                option[randno].setBackground(Color.green);
                option[0].setEnabled(false);                
                option[2].setEnabled(false);
                option[1].setEnabled(false);
                this.sec = 1;
                this.flagopt=false;
                waitimer.start();
            }
        }
        if(aobj.getSource()==roller)
        {
            QuizGen q = new QuizGen();
            int randdice = q.getranddice();
            roller.setIcon(dice[randdice]);
            sobj.playone("Audio/dice.wav");
            
            if(randdice == 5)
            {
                Yougot.setText("You got "+(randdice+1)+".");
                
                if(player1obj.getturnflag()==true)
                {

                    if(player1obj.getplace()+randdice+1 <= 100)
                    {
                    player1obj.setplace(player1obj.getplace()+(randdice+1));
                    Yougot.setVisible(true);
                    option[randno].setBackground(new Color(181,226,255));
                    cord cobj = new cord(player1obj.getplace());
                    p1.setBounds(cobj.getp1x(),cobj.getp1y(),26,40);
                    check.start();
                    }

                    if(player1obj.getplace()==100)
                    {
                      float srate1 = (float)((float)Integer.parseInt(player1obj.getcorrectans())/(float)player1obj.getquestno())*(float)100;
                      player1obj.setsrate(srate1);
                      Database dobj = new Database();
                      dobj.checkhighscore(player1obj.getname(),player1obj.getquestno(),player1obj.getsrate());
                      sobj.playone("Audio/celebrate.wav");
                      winnertimer.start();
                    }
                }
            
                if(player2obj.getturnflag()==true)
                {

                    if(player2obj.getplace()+randdice+1 <= 100)
                    {
                    player2obj.setplace(player2obj.getplace()+(randdice+1));
                    Yougot.setVisible(true);
                    option[randno].setBackground(new Color(181,226,255));
                    cord cobj = new cord(player2obj.getplace());
                    p2.setBounds(cobj.getp1x(),cobj.getp1y(),26,40);
                    check.start();
                    }
                
                    if(player2obj.getplace()==100)
                    {
                     int srate2 = (Integer.parseInt(player2obj.getcorrectans())/player2obj.getquestno())*100;
                     player2obj.setsrate(srate2);
                     Database dobj = new Database();
                     dobj.checkhighscore(player1obj.getname(),player1obj.getquestno(),player1obj.getsrate());
                     sobj.playone("Audio/celebrate.wav");
                     winnertimer.start();   
                    }
                }
            }

            else if(randdice!=5)
            {
                Yougot.setText("You got "+(randdice+1)+".");
                Yougot.setVisible(true);
                if(player2obj.getname().equals("Computer"))  //ONLY APPLICABLE FOR MODE 1
                {
                    rollerflag--;
                }

                if(player1obj.getturnflag()==true)   //MODE 1 & MODE 2 PLAYER 1
                {

                    if(player1obj.getplace()+randdice+1 <= 100)
                    {
                    player1obj.setplace(player1obj.getplace()+(randdice+1));
                    // cord cobj = new cord(player1obj.getplace());
                    // p1.setBounds(cobj.getp1x(),cobj.getp1y(),18,18);    
                    // option[randno].setBackground(new Color(181,226,255));
                    roller.setDisabledIcon(dice[randdice]);
                    roller.setEnabled(false);
                    check.start();

                    if(player1obj.getplace()==100)
                    {
                        float srate1 = (float)((float)Integer.parseInt(player1obj.getcorrectans())/(float)player1obj.getquestno())*(float)100;
                        player1obj.setsrate(srate1);
                        Database dobj = new Database();
                        dobj.checkhighscore(player1obj.getname(),player1obj.getquestno(),player1obj.getsrate());
                        sobj.playone("Audio/celebrate.wav");
                        winnertimer.start();
                    }

                    if((player2obj.getname().equals("Computer")==false) && player1obj.getplace()<100)  //MODE 2 APPLICABLE
                    {
                    changeturn.start();
                    }



                    }
                    // else{changeturn.start();}
                    
                    // if(player1obj.getplace()==100)
                    // {
                    //   float srate1 = (float)((float)Integer.parseInt(player1obj.getcorrectans())/(float)player1obj.getquestno())*(float)100;
                    //   String str = String.format("%.2f",srate1);
                    //   System.out.println("srate = "+str);
                    // }
                }
                
                if(player2obj.getturnflag()==true)  //MODE 2 PLAYER 2
                {
                    if(player2obj.getplace()+randdice+1 <= 100)
                    {
                    player2obj.setplace(player2obj.getplace()+(randdice+1));  
                    option[randno].setBackground(new Color(181,226,255));
                    roller.setDisabledIcon(dice[randdice]);
                    roller.setEnabled(false);
                    check.start();
                    }
                    
                    if(player2obj.getplace()==100)
                    {
                     int srate2 = (Integer.parseInt(player2obj.getcorrectans())/player2obj.getquestno())*100;
                     player2obj.setsrate(srate2);
                     Database dobj = new Database();
                     dobj.checkhighscore(player1obj.getname(),player1obj.getquestno(),player1obj.getsrate());
                     sobj.playone("Audio/celebrate.wav");
                     winnertimer.start();
                    }
                    
                    if(player2obj.getplace()<100)
                    {changeturn.start();}
                }

                if(player2obj.getname().equals("Computer") && player1obj.getplace()!=100) //MODE 1 PLAYER 2 OR WE CAN SAY COMPUTER'S TURN
                {compturn();}
            }
        }
    }
}


/***************************************
   Winning class will just display the winner's name score and his succcessrate on the screen.
   And a main menu button will take the user to the main menu which our Select class inside the code.
 ***************************************/
class Winning implements ActionListener
{
    JFrame frame;
    JButton MainMenu;
    JLabel bg,resultlab;

    Player winnerobj;
    Sound sobj;

    Border border = BorderFactory.createLineBorder(Color.white,3);

    ImageIcon bgimg = new ImageIcon("Pics/winning.jpg");
    public Winning(Sound sobj1,Player winner)
    {
        try
        {  
            this.sobj = (Sound)sobj1.clone();
            this.winnerobj = (Player)winner.clone();
        }catch(Exception eobj){}

        frame = new JFrame();
        MainMenu = new JButton();
        bg = new JLabel();
        resultlab = new JLabel();

        frame.setSize(815,640);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        bg.setBounds(0,0,800,600);
        bg.setIcon(bgimg);
        bg.setVisible(true);

        resultlab.setBounds(264,207,303,276);
        resultlab.setBackground(new Color(242,158,68));
        resultlab.setOpaque(true);
        resultlab.setForeground(Color.black);
        resultlab.setFont(new Font("Serif",Font.BOLD,26));
        resultlab.setHorizontalAlignment(JLabel.CENTER);
        resultlab.setVerticalAlignment(JLabel.TOP);
        resultlab.setText("<html>&nbsp;&nbsp;&nbsp;"+winnerobj.getname()+"<br/><br/>Success-rate<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+winnerobj.getsrate()+"<br/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Score<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ winnerobj.getcorrectans()+"</html>");
        resultlab.setBorder(border);

        MainMenu.setBounds(308,517,203,53);
        MainMenu.setText("Main Menu");
        MainMenu.setBackground(new Color(211,172,123));
        MainMenu.setForeground(Color.black);
        MainMenu.setFont(new Font("Serif",Font.BOLD,26));
        MainMenu.setVisible(true);
        MainMenu.setFocusable(false);

        MainMenu.addActionListener(this);
        
        frame.add(MainMenu);
        frame.add(resultlab);
        frame.add(bg);

        frame.setLayout(null);
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent aobj)
    {
        if(aobj.getSource()==MainMenu)
        {
            sobj.playone("Audio/click.wav");
            frame.dispose();
            try
            {
            Select sobj1 = new Select(sobj);
            }
            catch(Exception eobj){}
        }
    }
}