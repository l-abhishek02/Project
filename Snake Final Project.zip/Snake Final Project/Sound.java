package Audio;
import java.io.File;
import javax.sound.sampled.*;


/*
*******************************************************************

    Methos
      play method will play the bg music continously on loop
      playone method will play the notification sounds just once it requires argument which is the path of our audio file to play that file once.
      set music method will just change the boolean musicflag's variable value from true to false or vise versa 
      , according to which the code will decide whether to play the bg music or not
      same explaination for setsound  methods.
      
      now whenever someone set's the musicflag to false
      then by calling the musicoff method we stop the clip playing continously on loop in bg(background)

      now whenever someone set's the musicflag to true
      then by calling the musicon method we start the clip again playing continously on loop in bg(background)

      clone method is just the compulsory which need to be initialised inside our class as it implements the Cloneable Interface.
      Cloneable Interface allows us to clone a object whenever need , this happens with some exception hence we use it inside an try and catch block always.

*******************************************************************
*/

public class Sound implements Cloneable
{
    public String bgaudio;
    public Boolean soundflag,musicflag;
    public Clip clip;

    public Sound(String str)
    {
        bgaudio = str;
    }
    
    public void play()
    {
        try
        {
        
            File file = new File(bgaudio);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
            clip = AudioSystem.getClip();
            clip.open(audioStream);
            clip.loop(Clip.LOOP_CONTINUOUSLY);
            clip.start();
        
        }
        catch(Exception eobj)
        {}
    }

    public void playone(String path)
    {
        
        try
        {        
        if(soundflag == true)
        {
            File file = new File(path);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);
            clip.start();
        }
        }
        catch(Exception eobj)
        {}
    }

    public void musicoff()
    {
        clip.stop();
    }

    public void musicon()
    {
        clip.loop(Clip.LOOP_CONTINUOUSLY);
        clip.start();
    }

    public void setsound(boolean flag)
    {
        this.soundflag=flag;
    }
    
    public void setmusic(boolean flag)
    {
        this.musicflag=flag;
    }

    public Object clone() throws CloneNotSupportedException 
    {
        return super.clone();
    }
}