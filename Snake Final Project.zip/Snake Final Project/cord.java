package Quiz;

/********************************************************
  cord(co-ordinate) is a user defined package/library.
  
  this sets up the co ordinates for our piece whenever it lands on a specific number on the board.
  for every left to right moving numbers row we created array of name arr and
  for every right to left moving numbers row we created array of name arr1 

            According to which the pieces will move,
    
  for moving the piece we calculated every starting pixel of each row and distance between 2 block of place and according to it's one's place number we are calculating the remaining pixel to place the pieces at that specific co ordinating by calculating that points coordinates and assign it to the pieces of the player
  consider below example:

        if on 25,
        then suppose for 21 the x axis and y axis coordinates are 80 and 120 then for the the row the 21 to 30 the y axis will remain constant. and for x axis we will multiply the distant between 2 block * the one's place i.e 5 and will add it to the starting point of x axis;

        Mathematical explaination

            player place = 25
            distance between 2 blocks = 46
            21st is the starting position of that row so 21st places x and y axis is 80 and 120.(we are more interested in x axis i.e 80)
            so formula is
            player's pieces coordinate = starting row x axis + ( distance between 2 blocks * one's place digit of current player's place-1).
            player's pieces coordinate = 80 + (46 * 5-1)
                                       = 80 + (46 * 4)
                                       = 264 is the x axis coorinates of 25th place on board.

        Methods

           get p1x and p1y will return the coordinates for player 1
           get p2x and p2y will return the coordinates for player 2
           
*********************************************************/

public class cord
{
    int place;
    int x;
    int y;
    int arr[]={1,21,41,61,81};
    int arr1[]={11,31,51,71,91};
    int placeremainder;

    public cord(int plac)
    {        
        this.place = plac;
        for(int i = 0 ; i<5 ; i++)
        {
            if(arr[i]<=place && place<=(arr[i]+9))
            {
                x=176;
                if(place<=10)
                {
                    x = x + (46*(place-1));
                    break;
                }
                else
                {
                placeremainder = place%10;
                if(place>10 && placeremainder==1)
                {
                    x=176;
                    break;
                }
                else if(place>10 && placeremainder != 1 && placeremainder!=0)
                {
                    x = x + (46*(placeremainder-1));
                    break;
                }
                else if(place>10 && placeremainder != 1 && placeremainder==0)
                {
                    x = x + (46*(9));
                    break;
                }
                }
                
            }
            else if(arr1[i]<=place && place<=(arr1[i]+9))
            {
                x=586;
                placeremainder = place%10;

                if(placeremainder==1)
                {
                    x=586;
                    break;
                }
                else if(placeremainder==0)
                {
                    x = x - ((9)*46);
                    break;
                }
                else if(placeremainder!=1 && placeremainder!=0)
                {
                    x = x - (46*(placeremainder-1));
                    break;
                }
                
            }  
        }
        
        if(1<=place && place<=10)
        {
            y=443;
        }
        else if(11<=place && place<=20)
        {
            y=399;
        }
        else if(21<=place && place<=30)
        {
            y=353;
        }
        else if(31<=place && place<=40)
        {
            y=308;
        }
        else if(41<=place && place<=50)
        {
            y=262;
        }
        else if(51<=place && place<=60)
        {
            y=217;
        }
        else if(61<=place && place<=70)
        {
            y=171;
        }
        else if(71<=place && place<=80)
        {
            y=125;
        }
        else if(81<=place && place<=90)
        {
            y=79;
        }
        else if(91<=place && place<=100)
        {
            y=31;
        }

    }

    public int getp1x()
    {
        return this.x;
    }
    
    public int getp1y()
    {
        return this.y;
    }

    public int getp2x()
    {
        return (this.x+15);
    }
    
    public int getp2y()
    {
        return this.y;
    }
}