package Quiz;
import java.sql.*;
import javax.swing.*;



/******************************************************************
 This is an User defined package or we can a library created by us to simplied the main game code.

 This code will make the connections with the database that is created inside your system,
 this database contains all the highscore made by the players.

 Methods
    checkhighscore =  this method will just check that whether a player has broken any precious highscore record,
      IF YES - then his name will get exchanged with the previous highscore record maker.
      IF NO - nothing will happen.

    
    showhighscore = this method will get all the data from the database and will store it in a string and will return this string to the Home.java file's Select class from this select class whenever someone tries to check the highscore this string get printed in front of user.

    for JDBC (java database connnection)
    we need a connector of sql to java and then after setting it in our environment,
    we need install sql in our system through xampp
    and then we can give the path of our database by declaring 3 variable 
       url
       user
       pw
       all this for our mysql database.

 ******************************************************************/

public class Database
{
    String url = "jdbc:mysql://localhost:3306/snake_data";
    String user = "root";
    String pw = "";

    public void checkhighscore(String uname,int qno,float srate)
    {
        int i=1;
        try{
        Connection conn = DriverManager.getConnection(url,user,pw);
        Statement sobj =  conn.createStatement();
        String Query = "select * from highscore";
        ResultSet robj =  sobj.executeQuery(Query);
        
        String Query1 = "update highscore set username='"+uname+"',questno="+qno+",successrate="+srate+"where pno="+i;

        while(robj.next())
        {
            String dbuname = robj.getString("username");
            int dbqno = robj.getInt("questno");
            float dbsrate = robj.getFloat("successrate");
        
            if(dbqno<qno && dbsrate<srate)
            {
                sobj.execute(Query1);
                break;
            }
            i++;
        }

        }
        catch(Exception eobj){}
    }

    public String showhighscore()
    {
        String str = "<html><p>Sr.no&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Success-rate";
        try
        {
        JLabel lab1=new JLabel();
        JLabel lab2=new JLabel();
        JLabel lab3=new JLabel();
        JLabel lab4=new JLabel();
        JLabel lab5=new JLabel();

        JLabel lab[] = {lab1,lab2,lab3,lab4,lab5};
        Connection conn = DriverManager.getConnection(url,user,pw);
        Statement sobj = conn.createStatement();
        String Query = "Select * from highscore";
        ResultSet robj = sobj.executeQuery(Query);
        int i = 0;

        while(robj.next())
        {
            str = str+("<html><p>&nbsp;&nbsp;&nbsp;"+robj.getInt("pno")+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+robj.getString("username")+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+robj.getFloat("successrate"))+"<br/><br/>";
            i++;
        }
        }
        catch(Exception eobj){}
        str = str+"</html>";
        return str;
    }

}
