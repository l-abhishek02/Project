import Screens.Home;


//Just calling the class file which contains all the class of all the screens that will get displayed while playing the game.

class Start
{
    public static void main(String []args)
    {
        Home hobj = new Home();
    }
}