package Profile;
import javax.swing.*;
import java.awt.*;

/*
**********************************************
 All the set methods are used to set the players 
  1 profile 
  2 username changed placed from current position
  3 correctly answered quesiton
  4 question asked to a player
  5 his/her successrate by calculating it.
  6 and setting his/her turnflag
    IF true then his/her turn
    IF false then the opponents turn. 

 All the get methods are used to get this variable values and to display them or to give condition inside our maingame class which belongs to the Home.java file.

*********************************************
*/




public class Player implements Cloneable
{
    boolean select = false;
    ImageIcon profile;
    String username;
    int rightans = 0;
    int questno = 0;
    float srate = 0.0f;
    int place=1;
    boolean turnflag;
   

    //## SET METHODS
    public void setselect(boolean stat)
    {
        this.select = stat;
    }

    public void setplace(int value)
    {
        this.place=value;
    }

    public void setname(String uname)
    {
        this.username = uname;
    }

    public void setcorrectans(int value)
    {
        this.rightans = this.rightans+value;
    }
    
    public void resetcorrectans(int value)
    {
        this.rightans = 0;
    }

    public String getcorrectans()
    {
        String sc1=String.format("%02d",rightans);
        return sc1;
    }

    public void setquestno(int value)
    {
        this.questno = this.questno + value;
    }
    public void resetquestno(int value)
    {
        this.questno = 0;
    }

    public void setprofile(ImageIcon prof)
    {
        this.profile = prof;
    }

    public void setturnflag(boolean b)
    {
        this.turnflag = b;
    }

    public void setsrate(float f)
    {
        this.srate = f;
    }

    //### GET METHODS
    public int getplace()
    {
        return place;
    }

    public String getname()
    {
        return username;
    }

    public ImageIcon getprofile()
    {
        return profile;
    }

    public boolean getselectstat()
    {
        return select;
    }

    public boolean getturnflag()
    {
        return turnflag;
    }

    public int getquestno()
    {
        return questno;
    }

    public float getsrate()
    {
        return srate;
    }

    public Object clone() throws CloneNotSupportedException
    {
        return super.clone();
    }
}